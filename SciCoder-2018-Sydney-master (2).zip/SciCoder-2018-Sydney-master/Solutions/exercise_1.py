#!/usr/bin/env python

# This script reads the sample student data file and generates
# a few reports. The approach is to read all of the data into
# a list of dictionaries (one for each student), then generate
# the results.

datafile_path = "../Data Files/student_data.txt"

column_names = None

students = list()

with open(datafile_path) as f:
	for line in f:
		if line[0] == '#':
			continue # comment, go to next line
		else:
			line = line.rstrip("\n") # remove trailing new line
		if column_names is None:
			# found header
			column_names = line.split("|")
		else:
			# this is a student record
			student_record = dict(zip(column_names, line.split("|")))
			students.append(student_record)

assert(len(students) > 0, "Data wasn't read!")

# All students have been read from file as a list of dictionaries.
# Generate reports.

# 1. A list of all students from Attleboro.
#    --------------------------------------
# for-loop method
print("Students in Attleboro:\n"
      "----------------------")
for student in students:
	if student["city"] == "Attleboro":
		print(f"{student['first_name']} {student['last_name']}")

print() # blank line

# list comprehension method
print("Students in Attleboro:\n"
      "----------------------")
[print(f"{s['first_name']} {s['last_name']}") for s in students if s['city'] == 'Attleboro']

print()

# 2. A list of students supervised by Baker.
#    ---------------------------------------
print("Students supervised by Baker:\n"
      "-----------------------------")
[print(f"{s['first_name']} {s['last_name']}") for s in students if "Baker" in s["supervisors"]]

print()

# 3. A list of all clubs, and a list of students in each.
#    ----------------------------------------------------
# get the list of clubs
club_names = set() # a set cannot contain duplicate objects, which is what we want
for student in students:
	for club in student["club"].split(", "):
		if len(club) > 0: # a student may not necessarily belong to any club.
			club_names.add(club)

print(f"List of clubs: {sorted(club_names)}\n\n")

# Create a dictionary: key=<club name>, value=<list of students in club>
club_members = dict()
for club_name in club_names:
	club_members[club_name] = list() # create empty list to add students to
	
# Or, if we want to be fancy-pants, this is the same:
#club_members = dict([(club_name, list()) for club_name in club_names])

# populate the club lists
for student in students:
	for club_name in club_names:
		if club_name in student["club"]:
			club_members[club_name].append(student)

# print membership
for club_name in sorted(club_names):
	# print header and divider line of same length
	header = f"{club_name} Members"
	print(header + "\n" + "-"*len(header))
	
	# members of club
	for student in club_members[club_name]:
		print("{first_name} {last_name}".format(**student))
	
	print() # leave a blank line between clubs

