#!/usr/bin/env python

# This is a second version of the first exercise. It differs
# in that it builds the lists it needs while reading the
# file. This avoids looping over every student repeatedly
# for each report.

datafile_path = "../Data Files/student_data.txt"

column_names = None
club_members = dict() # key=<club name>, value=<list of students>
attleboro = list()	  # students from Attleboro
baker = list()		  # students supervised by Baker

with open(datafile_path) as f:
	for line in f:
		if line[0] == '#':
			continue # comment, go to next line
		else:
			line = line.rstrip("\n") # remove trailing new line

		if column_names is None:
			# found header
			column_names = line.split("|")
		else:
			# this is a student record
			student = dict(zip(column_names, line.split("|")))
			
			# we'll use this a few times
			name = "{first_name} {last_name}".format(**student)

			# from Attleboro?
			if student["city"] == "Attleboro":
				attleboro.append(name)
				
			# Baker's student?
			if "Baker" in student["supervisors"]:
				baker.append(name)
				
			# list of clubs
			for club_name in student["club"].split(", "):
				if len(club_name) > 0:
					# add student to club members
					if club_name in club_members:
						club_members[club_name].append(name)
					else:
						# first member of this club
						club_members[club_name] = [name]

# Print reports
# -------------
# 1. A list of all students from Attleboro.
print("Students in Attleboro:\n"
      "----------------------")
print("\n".join(attleboro))
print()

# 2. A list of students supervised by Baker.
print("Students supervised by Baker:\n"
      "-----------------------------")
print("\n".join(baker))
print()

# 3. A list of all clubs...
# the keys of the club_members dictionary are a distinct list of clubs
print(f"List of clubs: {club_members.keys()}")
print()

# ...and a list of students in each.
for club_name in sorted(club_members.keys()):
	print(f"{club_name}" + "\n" + "-" * len(club_name))
	print("\n".join(club_members[club_name]))
	print()

