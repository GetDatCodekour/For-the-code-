#!/usr/bin/env python

'''
Write a script that:

• reads the data file "../Data Files/sdss_spectra_links.txt"
• prints a random selection of URLs to the command line without duplicates

This version of the script uses 'argparse' to read the filename and the number to print.
'''

import sys
import random
import argparse
from os.path import basename

# Note: "__file__" is the name (and full path) of the program being run.

parser = argparse.ArgumentParser(description="Reads a file of URLs and prints a random selection of them.",
                                 usage="{0} --filename <file of URLs> --count n".format(basename(__file__)))

parser.add_argument('-f', '--filename',
					required=True,
					help="path to file")
parser.add_argument('-c', '--count',
					required=True,
					type=int,
					help="number of URLs to print")

# If someone types the name of the program with no arguments, let's
# have argparse print the help message and quit.
#
# The full command + argument list can be read from sys.argv.
# The arguments are sys.argv[1:] (the name of the program is sys.argv[0].
#
if len(sys.argv[1:]) == 0:
    print()
    parser.print_help()
    parser.exit()
    print()

args = parser.parse_args()

#filename = "sdss_spectra_links.txt"
#number_to_print = 10

filename = args.filename
number_to_print = args.count

# Read the file and place all of the URLs in a list.
#
url_list = list()
with open(filename) as datafile:
	for line in datafile:
		line = line.rstrip("\n")
		url_list.append(line)
		
assert len(url_list) > 0, "There was a problem reading the data file."

# random.randint(a, b) -> Return a random integer N such that a <= N <= b

# Solution 1
#
# Build of list of random numbers within the range 0, len(url_list)-1,
# then use as the index of the URL list.
#
random_idx = list()
while len(random_idx) < number_to_print:
	idx = random.randint(0, len(url_list)-1)
	if idx not in random_idx: # avoid duplicates
		random_idx.append(idx)

for idx in random_idx:
	print(url_list[idx])

print()

# Solution 2
#
# Randomly select a number between 0 and the length of the list - 1.
# Immediately print URL at that position, then remove it from the list.
# This avoids duplicates since we remove the URL as it's selected.
#
for i in range(number_to_print):
	print (url_list.pop( random.randint(0, len(url_list)-1)) )

# or in one line of code using list comprehension:
#
#[print(url_list.pop( random.randint(0, len(url_list)-1))) for x in range(number_to_print)]
