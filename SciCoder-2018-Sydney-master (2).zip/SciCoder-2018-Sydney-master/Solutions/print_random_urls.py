#!/usr/bin/env python

'''
Write a script that:

* reads the data file "../Data Files/sdss_spectra_links.txt"
* prints a random selection of URLs to the command line without duplicates
'''

import random

filename = "../Data Files/sdss_spectra_links.txt"
number_to_print = 10

# Read the file and place all of the URLs in a list.
#
url_list = list()
with open(filename) as datafile:
	for line in datafile:
		line = line.rstrip("\n")
		url_list.append(line)
		
assert len(url_list) > 0, "There was a problem reading the data file."

# random.randint(a, b) -> Return a random integer N such that a <= N <= b

# Solution 1
#
# Build of list of random numbers within the range 0, len(url_list)-1,
# then use as the index of the URL list.
#
random_idx = list()
while len(random_idx) < number_to_print:
	idx = random.randint(0, len(url_list)-1)
	if idx not in random_idx: # avoid duplicates
		random_idx.append(idx)

for idx in random_idx:
	print(url_list[idx])

print()

# Solution 2
#
# Randomly select a number between 0 and the length of the list - 1.
# Immediately print URL at that position, then remove it from the list.
# This avoids duplicates since we remove the URL as it's selected.
#
for i in range(number_to_print):
	print (url_list.pop( random.randint(0, len(url_list)-1)) )

# or in one line of code using a list comprehension:
#
#[print(url_list.pop( random.randint(0, len(url_list)-1))) for x in range(number_to_print)]
