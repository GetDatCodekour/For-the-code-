# SciCoder-2018-Sydney
Repository for the SciCoder 2018:Sydney workshop.
